"""Test Package for guessing game.

Author: Ahat Orazgeldiyev ahato@ksu.edu
Version:

"""
